<?php
add_theme_support('automatic-feed-links');