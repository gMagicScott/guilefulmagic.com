<script type="text/javascript">
var should_show_insert = <?php echo (isset($_REQUEST['send_to_premise_field_id']) ? 'true' : 'false'); ?>;
</script>
<meta id="send_to_premise_field_id" content="<?php echo esc_attr($_REQUEST['send_to_premise_field_id']); ?>" />