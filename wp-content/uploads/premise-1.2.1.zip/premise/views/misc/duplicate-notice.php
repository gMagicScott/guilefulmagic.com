<div class="updated fade" id="post-duplicated-message">
	<p>
		<?php printf(__('A duplicate of this post has been created for you.  You can <a href="%s">edit it here</a>', 'premise' ), get_edit_post_link($duplicate)); ?>
	</p>
</div>