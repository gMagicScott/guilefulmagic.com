<div id="premise-sent-support-request" class="updated fade">
	<p><strong><?php _e('Support Request Sent!', 'premise' ); ?></strong></p>
</div>
