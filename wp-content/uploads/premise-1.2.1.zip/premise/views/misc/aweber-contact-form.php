<div class="entry-optin-optin align<?php echo $align; ?>">
	<?php if( $title ) { ?>
	<div class="optin-header"><?php echo esc_html( $title ); ?></div>
	<?php } ?>
	<div class="optin-box"><?php echo $script; ?></div>
</div>