<div class="error" id="premise-css-not-writable">
	<p><?php printf(__('The Premise theme\'s CSS directory is not writeable.  Please change the permissions on the directory <code>%s</code> to make it writeable.', 'premise' ), $directory); ?></p>
</div>