<script type="text/javascript">
function ConversionCount() {
	var gwoTracker=_gat._getTracker("<?php echo $accountId; ?>");
    gwoTracker._trackPageview("/<?php echo $testId; ?>/goal");
    return true;
}
</script>