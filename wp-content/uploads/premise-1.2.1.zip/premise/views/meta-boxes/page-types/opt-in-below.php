<?php
$meta = $this->getPremiseMeta($post->ID);
premise_the_editor($meta['below-optin-copy'], 'premise[below-optin-copy]', '', true, 6);