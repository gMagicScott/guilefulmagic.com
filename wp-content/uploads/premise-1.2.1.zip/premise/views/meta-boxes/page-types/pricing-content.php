<h4><?php _e('Above Pricing Table', 'premise' ); ?></h4>
<?php premise_the_editor($meta['above-pricing-table-copy'], 'premise[above-pricing-table-copy]', '', true, 6); ?>

<h4><?php _e('Below Pricing Table', 'premise' ); ?></h4>
<?php premise_the_editor($meta['below-pricing-table-copy'], 'premise[below-pricing-table-copy]', '', true, 7); ?>