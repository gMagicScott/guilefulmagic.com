<?php
$meta = $this->getPremiseMeta($post->ID);
premise_the_editor($meta['below-video-copy'], 'premise[below-video-copy]', '', true, 6);