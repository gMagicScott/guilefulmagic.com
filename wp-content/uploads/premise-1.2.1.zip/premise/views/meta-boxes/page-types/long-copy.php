<?php $meta = $this->getPremiseMeta($post->ID); ?>
