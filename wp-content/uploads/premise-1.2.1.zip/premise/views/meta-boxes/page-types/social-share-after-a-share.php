<p>
	<?php _e('Enter the page elements and copy you want displayed after a read shares the page.  This is where you give them what you promised them for sharing the page.', 'premise' ); ?>
	<?php premise_the_editor($meta['after-a-share-page'], 'premise[after-a-share-page]', '', true, 6); ?>
</p>