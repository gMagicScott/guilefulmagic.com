<p>
	<?php _e('Enter the page elements and copy you want displayed before a reader shares the page.  This is your teaser page.', 'premise' ); ?>
	<?php premise_the_editor($meta['teaser-page'], 'premise[teaser-page]', '', true, 6); ?>
</p>